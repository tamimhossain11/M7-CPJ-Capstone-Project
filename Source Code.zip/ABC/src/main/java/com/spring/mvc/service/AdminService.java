package com.spring.mvc.service;

import com.spring.mvc.model.Admin;

public interface AdminService {
	public Admin adminlogin(Admin admin);
}
