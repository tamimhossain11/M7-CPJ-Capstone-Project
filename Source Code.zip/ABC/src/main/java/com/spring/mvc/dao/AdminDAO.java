package com.spring.mvc.dao;

import com.spring.mvc.model.Admin;
//to 
public interface AdminDAO {

	public Admin adminlogin(Admin admin);
}
